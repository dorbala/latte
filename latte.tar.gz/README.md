# latte
Online speech recognition engine based on barista, kaldi and gtkmm
