#include<iostream>

namespace bar {

   extern bool hideSig;
   extern int decoded_words;
};
